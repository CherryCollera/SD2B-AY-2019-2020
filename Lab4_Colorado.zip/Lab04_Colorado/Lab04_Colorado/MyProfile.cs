﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab04_Colorado
{
    class MyProfile
    {
        public void DisplayProfile()

        {
            System.Console.WriteLine("\n\n\n\t\t\t\tP R O F I L E");
            System.Console.WriteLine("Name:\t\t\t\tJohn Rey Colorado");
            System.Console.WriteLine("Birthday:\t\tNovember 14, 1999");
            System.Console.WriteLine("Course:\t\t\tBS Computer Science Major in Software Development");
            System.Console.WriteLine("Year:\t\t\t\t2nd Year");
            System.Console.WriteLine("Section:\t\t\tB");
            System.Console.ReadLine();
        }
    }
}
