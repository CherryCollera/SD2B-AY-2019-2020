﻿namespace Print
{
    internal class Accept
    {
    }
}