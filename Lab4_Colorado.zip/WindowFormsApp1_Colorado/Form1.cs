﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace WindowFormsApp1_Colorado
{
    public partial class Form1 
    {
        public Form1() 
        {
            InitializeComponent();
        }
        private void btn_getMessage_Click(object sender, EventArgs e)
        {
            HappyBirthday hb = new HappyBirthday();
            MessageBox.Show(hb.GetMessage("John"));
            this.Close();
        }
    }
}
