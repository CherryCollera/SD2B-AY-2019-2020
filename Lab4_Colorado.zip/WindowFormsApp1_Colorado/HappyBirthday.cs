﻿using System;
namespace WindowFormsApp1_Colorado
{
    class HappyBirthday
    {
        public string GetMessage(string firstname)
        {
            return "Happy Birthday" + firstname;
        }
    }
}
