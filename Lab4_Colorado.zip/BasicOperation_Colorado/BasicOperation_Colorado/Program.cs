﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperation_Colorado
{
    class Program
    {
        class CompareNumber
        {
            static void Main(string[] args)
            {
                int num1, num2, num3;
                Console.Write("enter the first number:");
                num1 = Convert.ToInt32(Console.ReadLine());
                Console.Write("enter the second number:");
                num2 = Convert.ToInt32(Console.ReadLine());
                Console.Write("enter the third number:");
                num3 = Convert.ToInt32(Console.ReadLine());

                if ((num1 < num2) && (num1 > num3))
                {
                    Console.WriteLine("{0} is greater than {1} and {2} ", num1, num2, num3);
                    if (num2 < num3)
                    {
                        Console.WriteLine("{0} is less than {1}  ", num3, num1);
                        Console.WriteLine("{0} is less than {1}  ", num2, num1);
                    }
                    else
                    {
                        Console.WriteLine("{0} is less than {1}  ", num2, num1);
                        Console.WriteLine("{0} is less than {1}  ", num3, num1);
                    }
                }
                else if ((num2 > num1) && (num2 > num3))
                {
                    Console.WriteLine("{0} is greater than {1} and {2} ", num2, num1, num3);
                    if (num1 < num3)
                    {
                        Console.WriteLine("{0} is less than {1}  ", num3, num2);
                        Console.WriteLine("{0} is less than {1}  ", num1, num2);
                    }
                    else
                    {
                        Console.WriteLine("{0} is less than {1}  ", num1, num2);
                        Console.WriteLine("{0} is less than {1}  ", num3, num2);
                    }

                }
                else if ((num3 > num1) && (num3 > num2))
                {
                    Console.WriteLine("{0} is greater than {1} and {2} ", num3, num1, num2);
                    if (num1 < num3)
                    {
                        if (num1 < num2)
                            Console.WriteLine("{0} is less than {1}  ", num2, num3);
                        Console.WriteLine("{0} is less than {1}  ", num1, num3);
                    }
                    else
                    {
                        Console.WriteLine("{0} is less than {1}  ", num1, num3);
                        Console.WriteLine("{0} is less than {1}  ", num2, num3);
                    }
                }
                else
                {
                    Console.WriteLine("{0} , {1} and {2}  are all equal");
                }

                Console.ReadKey();
            }
        }
    }
}

    
